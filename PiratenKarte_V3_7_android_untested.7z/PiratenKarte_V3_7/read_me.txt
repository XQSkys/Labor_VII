HA Puzzle with a wide degree of difficulty

Wie Labor VII muss erst geschoben werden dazu mit der Maus auf die äussere Linke Kartenreihe oder obere Reihe, auf eines der jeweils 2. Felder klicken.

diese Variante/Branch ist "Piratenkarte" ein Schiebepussel. Es Funktioniert im grunde wie Labor VII nur das z.b. mit Paint der Spielstand
 mit einem Bild in der mitte wo die wege sind übermalt wird. und dann Jeder Pirat ein teil des Bildes Bekommt. Was jemand anders Wieder Zusammensetzt. 
 beim laden muss darauf geachtet werden das, vor dem landen die Schwierigkeit auf die selbe Kartenzahl gestellt wird wie der Spielstand/Puzzel.

meine Idee war alles nur mit einfachen png Bildern zu machen. So kann bei Hanoi einfach ein Stein dazugemalt werden oder durch bilder verändert wird.
 die obere Kante sollte dazu aber gerade sein.

Bei Piratenkarte kann geladen und gespeichert werden oder zum austauschen von Puzzeln. Nach dem Klicken auf den Speichern knopf wird dieser kurz Hellblau.
 es kan jederzeit gespeichert und geladen werden.