Labor_VII

A Labyrint Game for up to 4 Player


ich habe mich für GPL 3.0 Lizenz entschieden.


zum Spielen  benotigen sie:

Java:

https://java.com/de/download/


was kostet die Labor_VII app?
ich will dafür kein geld.
Anleitung: Bei Labor VII kann erst die Karte die der Aktive Pirat hat gedreht werden, durch Anklicken mit der Maus. Danach könnte geschoben werden, dazu mit der Maus auf die äussere Kartenreihe , auf eines der jeweils 2. Felder klicken. Die Spieler können sie anschließend durch die Tasten a ,s ,d ,w und y (stehen bleiben) bewegen. Ziel ist es das der eigene Pirat alleine auf den Feld zurück bleibt. Egal ob der Geger sammt Karte im Menu eines Piraten ist oder einfach "übermalt wurde". Die erzeugen 3bild*.png 5bild*.png 7bild*.png können zum beispiel mit Windows Paint bearbeitet werden. Wege müssen immer Weiss sein und Wände Schwarz. Wichtig ist das wenn sie Spieler versetzen: ausschneiden und einfügen, weil die richtige Farbe wichtig ist. Wärend des Spiels werden auch Spielstände Automatisch erzeugt in den 3save/ 5save/ und 7save/ abgelegt. oder per sofort klick auf einen knopf im Spiel. Die Zahl zeigt den Schwierigheits grad am also die Anzahl der Felder nebeneinander und sorgt dafür das nur passende Karten für ihr Spiel geladen werden. Der Film Butten erzeugt png Bilder die nummeriert sind. Diese können zum Beispiel mit dem Movie Maker aus Prozessing 3 zu Filmen gemacht werden. Wenn sie eine dieser bild.png nutzen wollen als Spielstand können sie sie in 3bild.png , 5bild.png 7bild.png umbennenen und ins Hauptverzeihniss legen.
Die Button oben in Labor VII haben fast alle eine funktion. die ist oft nutzlich aber auch riskant. Mit y stehenbleiben ist da oft eine erholung für deinen Pirat.
Die Piraten Lebensenergie werte sind ans aktuelle spiel gebunden sie werden beim neustart des Spiels wieder zurück auf normal gesetzt wenn ihr einem Freund den z.b. 7bild.png schickt sind die werte des empfängers in der geladenen map von seinem aktuellen spiel. laden und speichern kostet energie. wenn eure spieler erschöpft sind sie nur bei euch erschopft. der e-mail emphänger hat z.b. ausgerute spieler und laufen völlig "normal" über die zugeschickte map. ihr könnt den unteren grauen balken frei gestalten(text, bilder), das meiste andere auch. nur die karte selber ist etwas schwirig.
auch wer grade dran ist wird nicht übertragen. es ist der spieler des e-mail empfängers am zug.
wem es spass macht kann auch in die kartenstückecken Karoten äpfel oder sonsiges zeichen. werden diese von der karte geschoben landen sie beim aktiven piraten. ihr seht dann auch bei der 3x3er map das geschenk beim Piraten im karten fenster in kleiner version. ob er sich freut wenn ihr die karte dann dreht weiss ich nicht....


Das Tool zum umprogrammiern Programm finden sie unter: https://processing.org/ 

In der PreBeta0_7_2_8 werden die Filme(Bilderfolgen) nicht mehr zerlegt sondern landen alle in einem Ordner, ohne Zahl vor dem Namen.